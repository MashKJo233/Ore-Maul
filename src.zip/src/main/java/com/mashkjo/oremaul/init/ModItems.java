package com.mashkjo.oremaul.init;
import java.util.ArrayList;
import java.util.List;

import com.mashkjo.oremaul.items.ItemBase;
import com.mashkjo.oremaul.items.tools.ToolSword;

import net.minecraft.item.Item;
import net.minecraft.item.Item.ToolMaterial;
import net.minecraft.item.ItemSword;
import net.minecraftforge.common.util.EnumHelper;

public class ModItems {

        public static final List<Item> ITEMS = new ArrayList<Item>(); 
        
        public static final Item RUBY = new ItemBase("ruby");
       
        public static final ToolMaterial MATERIAL_WOODEN = EnumHelper.addToolMaterial("material_wooden", 1, 59, 2.0F, 0.0F, 11);
        public static final ItemSword WOODEN_MAUL = new ToolSword("wooden_maul", MATERIAL_WOODEN);
        public static final ToolMaterial MATERIAL_STONE = EnumHelper.addToolMaterial("material_stone", 2, 133, 4.0F, 1.0F, 5);
        public static final ItemSword STONE_MAUL = new ToolSword("stone_maul", MATERIAL_STONE);
        public static final ToolMaterial MATERIAL_IRON = EnumHelper.addToolMaterial("material_iron", 3, 250, 6.0F, 4.0F, 14);
        public static final ItemSword IRON_MAUL = new ToolSword("iron_maul", MATERIAL_IRON);
        public static final ToolMaterial MATERIAL_GOLDEN = EnumHelper.addToolMaterial("material_golden", 0, 32, 12.0F, 1.0F, 19);
        public static final ItemSword GOLDEN_MAUL = new ToolSword("golden_maul", MATERIAL_GOLDEN);
        public static final ToolMaterial MATERIAL_DIAMOND = EnumHelper.addToolMaterial("material_diamond", 4, 1561, 8.0F, 6.0F, 11);
        public static final ItemSword DIAMOND_MAUL = new ToolSword("diamond_maul", MATERIAL_DIAMOND);
        public static final ToolMaterial MATERIAL_RUBY = EnumHelper.addToolMaterial("material_ruby", 4, 2000, 8.5F, 10.0F, 20);
        public static final ItemSword RUBY_MAUL = new ToolSword("ruby_maul", MATERIAL_RUBY);
}