package com.mashkjo.oremaul.items.tools;

import com.mashkjo.oremaul.Main;
import com.mashkjo.oremaul.init.ModItems;
import com.mashkjo.oremaul.util.IHasModel;

import net.minecraft.item.ItemSword;

public class ToolSword extends ItemSword implements IHasModel{
	
	public ToolSword(String name, ToolMaterial material) {
		super(material);
		setUnlocalizedName(name); 
		setRegistryName(name); 
		setCreativeTab(Main.oremaul); 
		ModItems.ITEMS.add(this); 
	}
	
	@Override
	public void registerModels() {
		Main.proxy.registerItemRenderer(this, 0, "inventory"); 
	}
}
