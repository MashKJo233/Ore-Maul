package com.mashkjo.oremaul.items;

import com.mashkjo.oremaul.Main;
import com.mashkjo.oremaul.init.ModItems;
import com.mashkjo.oremaul.util.IHasModel;

import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.item.Item;

public class ItemBase extends Item implements IHasModel{ 

        public ItemBase(String name) {
                setUnlocalizedName(name); 
                setRegistryName(name); 
                setCreativeTab(Main.oremaul); 
                ModItems.ITEMS.add(this); 
        }
        
        @Override
        public void registerModels() {
                Main.proxy.registerItemRenderer(this, 0, "inventory"); 
        }

}
