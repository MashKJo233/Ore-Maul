package com.mashkjo.oremaul.util;

public interface IHasModel {
		public void registerModels();
}
