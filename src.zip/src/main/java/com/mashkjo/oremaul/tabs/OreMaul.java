package com.mashkjo.oremaul.tabs;

import com.mashkjo.oremaul.init.ModItems;

import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;

public class OreMaul extends CreativeTabs {

        public OreMaul(String label) {
                super("oremaul"); 
        }

        @Override
        public ItemStack getTabIconItem() {
                return new ItemStack(ModItems.RUBY); 
        }
}